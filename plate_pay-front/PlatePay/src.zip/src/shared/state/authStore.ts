import { create } from 'zustand';
// persist 미들웨어 관련 import를 제거합니다.
// import { persist, createJSONStorage } from 'zustand/middleware';
// import AsyncStorage from '@react-native-async-storage/async-storage';
import FCMService from '../../services/FCMService';

// MemberInfo 타입을 다른 파일에서 import해서 사용할 수 있도록 export 해줍니다.
export interface MemberInfo {
  memberUid: number;
  name: string | null;
  nickname: string | null;
  email: string;
  phoneNum: string | null;
  loginType: 'kakao' | 'ssafy';
  isActive: boolean | null;
}

// 저장소에서 관리할 전체 상태에 대한 타입 정의
interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  memberInfo: MemberInfo | null;
  isLoggedIn: boolean;
  // setAuthData가 AuthState의 일부만 받아도 되도록 Partial<>로 감싸줍니다.
  setAuthData: (data: Partial<Omit<AuthState, 'setAuthData' | 'clearAuthData'>>) => void;
  clearAuthData: () => void;
}

// Zustand를 사용하여 상태 저장소 생성
// persist 미들웨어를 제거하여 앱을 재시작할 때마다 로그인 상태가 초기화되도록 합니다.
export const useAuthStore = create<AuthState>()((set) => ({
  // 초기 상태 값
  accessToken: null,
  refreshToken: null,
  memberInfo: null,
  isLoggedIn: false,
  // set 함수가 기존 state와 새로운 data를 합치도록 수정합니다.
  setAuthData: (data) => {
    const newState = {
      ...data,
      isLoggedIn:
        !!(data.accessToken || data.accessToken !== null),
    };

    set((state) => ({ ...state, ...newState }));

    // 로그인 성공시 FCM 토큰 전송
    if (data.accessToken && data.memberInfo) {
      console.log('🔥 AUTH: Login successful, sending FCM token');
      FCMService.getCurrentToken().then(token => {
        if (token) {
          FCMService.sendTokenToServer(token);
        }
      }).catch(error => {
        console.log('🔥 AUTH: Failed to get FCM token after login:', error);
      });
    }
  },
  // 로그아웃 시 데이터를 초기화하는 함수
  clearAuthData: () =>
    set({
      accessToken: null,
      refreshToken: null,
      memberInfo: null,
      isLoggedIn: false,
    }),
}));
