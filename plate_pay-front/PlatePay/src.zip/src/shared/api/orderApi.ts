import { axiosInstance } from "./axiosInstance";
import { PendingOrderHistory, ApiResponse } from "../../types/type";

export const getPendingOrderHistory = async (plateNum: string): Promise<PendingOrderHistory | null> => {
  try {
    const response = await axiosInstance.get<ApiResponse<PendingOrderHistory>>(`/order-histories/pending?plateNum=${plateNum}`);
    return response.data.data || null;
  } catch (error) {
    console.error("Failed to fetch pending order history:", error);
    throw error;
  }
};
