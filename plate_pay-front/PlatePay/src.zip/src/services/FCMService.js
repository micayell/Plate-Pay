import messaging, {
  getMessaging,
  requestPermission,
  getToken,
  onMessage,
  setBackgroundMessageHandler,
  onNotificationOpenedApp,
  getInitialNotification,
  onTokenRefresh,
  AuthorizationStatus
} from '@react-native-firebase/messaging';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { axiosInstance } from '../shared/api/axiosInstance';
import { getApps, getApp } from '@react-native-firebase/app';
import notifee, { AndroidImportance } from '@notifee/react-native';

class FCMService {
  constructor() {
    this.initialized = false;
    // Notifee 초기화
    this.initializeNotifee();
    // Firebase가 준비될 때까지 초기화를 지연
    this.initWhenReady();
  }

  async initializeNotifee() {
    try {
      console.log('🔔 Initializing Notifee...');

      // Android 채널 생성
      const channelId = await notifee.createChannel({
        id: 'fcm-channel',
        name: 'FCM Notifications',
        description: 'Channel for FCM notifications',
        importance: AndroidImportance.HIGH,
        sound: 'default',
        vibration: true,
      });

      console.log(`🔔 Notifee channel created: ${channelId}`);
    } catch (error) {
      console.error('🔔 Error initializing Notifee:', error);
    }
  }

  async initWhenReady() {
    console.log('🔥 FCM: Starting FCM initialization process...');

    // Firebase 앱이 초기화될 때까지 대기
    let attempts = 0;
    const maxAttempts = 50; // 5초 대기 (100ms * 50)

    while (attempts < maxAttempts) {
      try {
        console.log(`🔥 FCM: Checking Firebase apps, attempt ${attempts + 1}, apps count: ${getApps().length}`);

        if (getApps().length > 0) {
          console.log('🔥 FCM: Firebase app detected!');
          console.log('🔥 FCM: Default app name:', getApp().name);
          console.log('🔥 FCM: Starting FCM initialization...');

          await this.init();
          console.log('🔥 FCM: ✅ FCM initialization completed successfully!');
          return;
        }
      } catch (error) {
        console.log('🔥 FCM: Error during Firebase check:', error.message);
      }

      await new Promise(resolve => setTimeout(resolve, 100));
      attempts++;
    }

    console.error('🔥 FCM: Firebase initialization timeout after 5 seconds');
    console.error('🔥 FCM: Firebase apps count still:', getApps().length);
  }

  async init() {
    if (this.initialized) {
      console.log('🔥 FCM: Already initialized, skipping');
      return;
    }

    try {
      console.log('🔥 FCM: Starting FCM service initialization...');

      console.log('🔥 FCM: Step 1 - Requesting permission...');
      await this.requestPermission();

      console.log('🔥 FCM: Step 2 - Getting FCM token...');
      await this.getToken();

      console.log('🔥 FCM: Step 3 - Setting up message handlers...');
      this.setupMessageHandlers();

      console.log('🔥 FCM: Step 4 - Setting up token refresh handler...');
      this.setupTokenRefreshHandler();

      this.initialized = true;
      console.log('🔥 FCM: ✅ All initialization steps completed successfully!');
    } catch (error) {
      console.error('🔥 FCM: ❌ Initialization failed:', error);
      console.error('🔥 FCM: Error details:', error.message);
    }
  }

  async requestPermission() {
    try {
      console.log('🔥 FCM: Requesting notification permission...');
      const messagingInstance = getMessaging();
      const authStatus = await requestPermission(messagingInstance);

      console.log('🔥 FCM: Raw authorization status:', authStatus);
      console.log('🔥 FCM: AUTHORIZED constant:', AuthorizationStatus.AUTHORIZED);
      console.log('🔥 FCM: PROVISIONAL constant:', AuthorizationStatus.PROVISIONAL);

      const enabled =
        authStatus === AuthorizationStatus.AUTHORIZED ||
        authStatus === AuthorizationStatus.PROVISIONAL;

      if (enabled) {
        console.log('🔥 FCM: ✅ Notification permission granted! Status:', authStatus);
      } else {
        console.log('🔥 FCM: ❌ Notification permission denied. Status:', authStatus);
      }

      return enabled;
    } catch (error) {
      console.error('🔥 FCM: ❌ Permission request error:', error);
      console.error('🔥 FCM: Error details:', error.message);
      return false;
    }
  }

  async getToken() {
    try {
      console.log('🔥 FCM: Attempting to get FCM token...');
      const messagingInstance = getMessaging();
      const token = await getToken(messagingInstance);

      if (token) {
        console.log('🔥 FCM: ✅ FCM Token obtained successfully!');
        console.log('🔥 FCM: Token length:', token.length);
        console.log('🔥 FCM: Token preview:', token.substring(0, 50) + '...');

        await AsyncStorage.setItem('fcm_token', token);
        console.log('🔥 FCM: Token saved to AsyncStorage');

        return token;
      } else {
        console.log('🔥 FCM: ⚠️ FCM Token is empty or null');
        return null;
      }
    } catch (error) {
      console.error('🔥 FCM: ❌ Get token error:', error);
      console.error('🔥 FCM: Error details:', error.message);
      return null;
    }
  }

  // 로그인 후 호출할 메소드
  async getCurrentToken() {
    try {
      // Firebase 앱 초기화 확인
      console.log('🔥 FCM: Checking Firebase apps:', getApps().length);

      if (getApps().length === 0) {
        console.log('🔥 FCM: No Firebase app found, cannot get token');
        return null;
      }

      console.log('🔥 FCM: Getting FCM token...');
      const messagingInstance = getMessaging();
      const token = await getToken(messagingInstance);
      console.log('🔥 FCM: Token retrieved successfully');
      return token;
    } catch (error) {
      console.log('🔥 FCM: Get current token error:', error);
      return null;
    }
  }

  setupMessageHandlers() {
    const messagingInstance = getMessaging();

    // Foreground message handler
    onMessage(messagingInstance, async remoteMessage => {
      console.log('🔔 Foreground message received:', remoteMessage);

      // Foreground에서 받은 메시지를 로컬 알림으로 표시
      this.showLocalNotification(remoteMessage);
    });

    // Background/Quit state message handler
    setBackgroundMessageHandler(messagingInstance, async remoteMessage => {
      console.log('Background message received:', remoteMessage);
      // Handle background message
    });

    // Notification opened app
    onNotificationOpenedApp(messagingInstance, remoteMessage => {
      console.log('Notification opened app:', remoteMessage);
      // Handle notification tap
    });

    // Check if app was opened from notification
    getInitialNotification(messagingInstance)
      .then(remoteMessage => {
        if (remoteMessage) {
          console.log('App opened from notification:', remoteMessage);
          // Handle app opened from notification
        }
      });
  }

  // 토큰 갱신 감지 설정
  setupTokenRefreshHandler() {
    const messagingInstance = getMessaging();
    onTokenRefresh(messagingInstance, async token => {
      console.log('FCM Token refreshed:', token);
      await AsyncStorage.setItem('fcm_token', token);
      // 토큰이 갱신되면 서버에 업데이트 전송
      await this.sendTokenToServer(token);
    });
  }

  // Foreground에서 받은 FCM 메시지를 시스템 알림으로 표시
  async showLocalNotification(remoteMessage) {
    try {
      const { notification, data } = remoteMessage;

      if (notification) {
        console.log('🔔 Showing system notification:', notification.title);

        // Notifee를 사용하여 시스템 알림 표시
        await notifee.displayNotification({
          title: notification.title || '알림',
          body: notification.body || '새 메시지가 도착했습니다',
          data: {
            ...data,
            messageId: remoteMessage.messageId,
            sentTime: remoteMessage.sentTime,
          },
          android: {
            channelId: 'fcm-channel',
            importance: AndroidImportance.HIGH,
            sound: 'default',
            vibrationPattern: [300, 500],
            smallIcon: 'ic_launcher', // 기본 아이콘 사용
            pressAction: {
              id: 'default',
              launchActivity: 'default',
            },
          },
        });

        console.log('🔔 System notification displayed successfully');
      } else {
        console.log('🔔 No notification payload, showing generic notification');

        // notification 없이 data만 있는 경우
        await notifee.displayNotification({
          title: '새 메시지',
          body: '새 메시지가 도착했습니다',
          data: data,
          android: {
            channelId: 'fcm-channel',
            importance: AndroidImportance.HIGH,
            sound: 'default',
            vibrationPattern: [300, 500],
            smallIcon: 'ic_launcher',
          },
        });
      }
    } catch (error) {
      console.error('🔔 Error showing system notification:', error);
    }
  }

  // 로그인 후 서버에 토큰 전송
  async sendTokenToServer(token) {
    try {
      console.log('🔥 FCM: Starting to send token to server');
      console.log('🔥 FCM: Token:', token);
      console.log('🔥 FCM: URL:', 'http://j13c108.p.ssafy.io:8080/api/v1/fcms/send');

      const payload = {
        token: token,
        title: 'Test Notification',
        body: 'FCM 토큰 등록 테스트'
      };
      console.log('🔥 FCM: Payload:', payload);

      const response = await axiosInstance.post('http://j13c108.p.ssafy.io:8080/api/v1/fcms/send', payload);

      console.log('🔥 FCM: Response status:', response.status);
      console.log('🔥 FCM: Response data:', response.data);
      console.log('🔥 FCM: Token sent successfully!');
    } catch (error) {
      console.log('🔥 FCM: Error occurred while sending token');
      console.log('🔥 FCM: Error message:', error.message);
      console.log('🔥 FCM: Error response:', error.response?.data);
      console.log('🔥 FCM: Error status:', error.response?.status);
    }
  }

}

export default new FCMService();