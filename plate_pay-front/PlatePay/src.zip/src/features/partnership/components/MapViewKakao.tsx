import React, { useEffect, useImperativeHandle, useMemo, useRef } from 'react';
import { StyleSheet, ViewStyle } from 'react-native';
import { WebView } from 'react-native-webview';

type MapMarker = { id: string; lat: number; lng: number; name?: string };

// 배열 또는 { markers: [] } 모두 허용
type Props = {
  jsKey: string;
  markers?: MapMarker[] | { markers: MapMarker[] };
  style?: ViewStyle;
  onReady?: () => void;
  onMarkerClick?: (id: string) => void;
  onLocateOk?: (coords: { latitude: number; longitude: number }) => void;
  onLocateError?: (reason: string | number) => void;
  autoLocateOnReady?: 'if-granted' | 'always' | false;
  hasNativeLocationPermission?: boolean;
  // 디버깅용: ready 직후 테스트 마커 1개 잠깐 찍기
  debugTestMarker?: boolean;
};

export type MapViewKakaoHandle = {
  locateMe: () => void;
  setCenter: (lat: number, lng: number, level?: number) => void;
  highlightMarker?: (id: string) => void;
  clearMarkers?: () => void;
  setMarkersDirect?: (markers: MapMarker[]) => void;
};

// RN 쪽 정규화
function normalizeMarkers(input?: MapMarker[] | { markers: MapMarker[] }): MapMarker[] {
  if (Array.isArray(input)) return input;
  if (input && Array.isArray((input as any).markers)) return (input as any).markers;
  return [];
}

const makeHtml = (JS_KEY: string) => `
<!doctype html><html lang="ko"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
<style>html,body,#map{height:100%;margin:0;padding:0}</style>
</head><body><div id="map"></div>
<script src="https://dapi.kakao.com/v2/maps/sdk.js?appkey=${JS_KEY}&autoload=false"></script>
<script>
  let map, myMarker;
  const markerList = [];
  const markerIndex = {};
  const infoIndex = {};
  let queuedMarkers = null;

  // 기본 스프라이트 접근 가능한지 진단 (CDN/정책 문제 파악)
  const DEFAULT_MARKER_URL = "https://t1.daumcdn.net/mapjsapi/images/2x/marker.png";
  let useFallbackImage = false;      // 🔁 막히면 true로 전환
  let defaultMarkerImage = null;     // 폴백 SVG를 캐시

  function postMsg(payload){
    try { window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(payload)); } catch(e){}
  }
  window.onerror = function(msg, src, line, col){ postMsg({ type:'jsError', msg: String(msg), src, line, col }); };

  function probeDefaultMarkerSprite(){
    try {
      const img = new Image();
      img.onload = function(){ postMsg({ type: 'probeSprite', ok: true, w: img.width, h: img.height, url: DEFAULT_MARKER_URL }); };
      img.onerror = function(e){
        useFallbackImage = true; // ❗️막히면 폴백 사용
        postMsg({ type: 'probeSprite', ok: false, err: String((e && e.message) || 'error'), url: DEFAULT_MARKER_URL });
      };
      img.src = DEFAULT_MARKER_URL + "?t=" + Date.now();
    } catch (e) {
      useFallbackImage = true;
      postMsg({ type: 'probeSprite', ok: false, err: String((e && e.message) || 'exception'), url: DEFAULT_MARKER_URL });
    }
  }

  function makeFallbackImage() {
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="40" viewBox="0 0 28 40"><path d="M14 0C6.82 0 1 5.82 1 13c0 9.75 13 27 13 27s13-17.25 13-27C27 5.82 21.18 0 14 0z" fill="#3B82F6"/><circle cx="14" cy="13" r="5" fill="white"/></svg>';
    const url = 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
    return new kakao.maps.MarkerImage(url, new kakao.maps.Size(28, 40), { offset: new kakao.maps.Point(14, 40) });
  }

  function clearMarkers(){
    markerList.forEach(m => m.setMap(null));
    markerList.length = 0;
    for (const k in markerIndex) delete markerIndex[k];
    for (const k in infoIndex) { try{ infoIndex[k].close(); }catch(e){} delete infoIndex[k]; }
  }

  function createMarkers(list){
    clearMarkers();

    if (useFallbackImage && !defaultMarkerImage) {
      defaultMarkerImage = makeFallbackImage(); // 필요할 때만 생성
    }

    const valid = [];
    (Array.isArray(list) ? list : []).forEach(p => {
      const id  = String(p.id ?? '');
      const lat = Number(p.lat);
      const lng = Number(p.lng);
      if (!id || !isFinite(lat) || !isFinite(lng)) return;

      valid.push({ id, lat, lng, name: p.name || '' });

      const ll = new kakao.maps.LatLng(lat, lng);
      const m  = new kakao.maps.Marker({
        position: ll,
        clickable: true,
        image: useFallbackImage ? defaultMarkerImage : undefined // ✅ 기본: 스프라이트, 막히면 폴백
      });
      m.setMap(map);
      markerList.push(m);
      markerIndex[id] = m;

      const info = new kakao.maps.InfoWindow({
        content: '<div style="padding:6px 8px;font-size:13px;white-space:nowrap">'+(p.name||'')+'</div>'
      });
      infoIndex[id] = info;

      kakao.maps.event.addListener(m,'click',function(){
        try { info.open(map, m); } catch(e){}
        postMsg({ type:'markerClick', id });
      });
    });

    postMsg({ type:'markersValidated', count: valid.length, first: valid[0] || null });

    if (valid.length === 1) {
      const p = valid[0];
      const ll = new kakao.maps.LatLng(p.lat, p.lng);
      map.setCenter(ll);
      map.setLevel(3, { animate: { duration: 200 } });
    } else if (valid.length > 1) {
      const bounds = new kakao.maps.LatLngBounds();
      valid.forEach(p => bounds.extend(new kakao.maps.LatLng(p.lat, p.lng)));
      map.setBounds(bounds);
    }
  }

  // ⚠️ WebView 쪽에서도 한 번 더 정규화 (객체로 오면 .markers 꺼냄)
  function normalizeInWV(list){
    try { if (typeof list === 'string') list = JSON.parse(list); } catch(e) { list = []; }
    if (!Array.isArray(list) && list && Array.isArray(list.markers)) list = list.markers;
    return Array.isArray(list) ? list : [];
  }

  window.setMarkers = function(list){
    const arr = normalizeInWV(list);
    postMsg({ type:'setMarkersCalled', length: arr.length, first: arr[0] || null });
    if (!map) { queuedMarkers = arr; return; }
    createMarkers(arr);
    postMsg({ type:'markersSet', count: arr.length });
  };

  window.highlightMarker = function(id){
    const m = markerIndex[id];
    if (!m) { postMsg({ type:'highlightMiss', id }); return; }
    const pos = m.getPosition();
    map.setCenter(pos);
    map.setLevel(3, { animate: { duration: 200 } });
    const info = infoIndex[id];
    if (info) try { info.open(map, m); }catch(e){}
  };

  window.setCenter = function(lat, lng, level){
    const ll = new kakao.maps.LatLng(Number(lat), Number(lng));
    map.setCenter(ll); map.setLevel(level ?? 3, { animate:{ duration:200 }});
  };

  window.locateMe = function(){
    if (!navigator.geolocation) { postMsg({ type:'locError', reason:'no_geolocation' }); return; }
    navigator.geolocation.getCurrentPosition(
      pos => {
        const { latitude, longitude } = pos.coords;
        const ll = new kakao.maps.LatLng(latitude, longitude);
        if (!myMarker) { myMarker = new kakao.maps.Marker({ position: ll }); myMarker.setMap(map); }
        else { myMarker.setPosition(ll); }
        map.setCenter(ll); map.setLevel(3,{ animate:{ duration:200 }});
        postMsg({ type:'locOk', coords:{ latitude, longitude } });
      },
      err => { postMsg({ type:'locError', reason: err.code || 'denied' }); },
      { enableHighAccuracy:true, timeout:8000, maximumAge:0 }
    );
  };

  window.clearMarkers = function(){ clearMarkers(); };

  kakao.maps.load(function() {
    map = new kakao.maps.Map(document.getElementById('map'), {
      center: new kakao.maps.LatLng(37.4979,127.0276), level: 6
    });

    // 🔎 기본 스프라이트 로드 테스트 (막히면 useFallbackImage = true)
    probeDefaultMarkerSprite();

    if (queuedMarkers) {
      createMarkers(queuedMarkers);
      postMsg({ type:'markersSetFromQueue', count: queuedMarkers.length || 0 });
      queuedMarkers = null;
    }

    postMsg({ type:'ready' });
  });
</script></body></html>
`;

const MapViewKakao = React.forwardRef<MapViewKakaoHandle, Props>(({
  jsKey,
  markers,
  style,
  onReady,
  onMarkerClick,
  onLocateOk,
  onLocateError,
  autoLocateOnReady = 'if-granted',
  hasNativeLocationPermission,
  debugTestMarker = false, // 기본 false
}, ref) => {
  const webRef = useRef<WebView>(null);
  const html = useMemo(() => makeHtml(jsKey), [jsKey]);

  const didAutoLocateRef = useRef(false);
  const lastMarkersJsonRef = useRef<string>('');

  useImperativeHandle(ref, () => ({
    locateMe: () => webRef.current?.injectJavaScript('window.locateMe && window.locateMe(); true;'),
    setCenter: (lat: number, lng: number, level?: number) =>
      webRef.current?.injectJavaScript(`window.setCenter && window.setCenter(${lat}, ${lng}, ${level ?? 3}); true;`),
    highlightMarker: (id: string) =>
      webRef.current?.injectJavaScript(`window.highlightMarker && window.highlightMarker(${JSON.stringify(id)}); true;`),
    clearMarkers: () =>
      webRef.current?.injectJavaScript('window.clearMarkers && window.clearMarkers(); true;'),
    setMarkersDirect: (mks: MapMarker[]) => {
      const json = JSON.stringify(mks ?? []);
      lastMarkersJsonRef.current = json;
      if (__DEV__) console.log('[RN->WV] setMarkersDirect len=', mks?.length, ' first=', mks?.[0]);
      webRef.current?.injectJavaScript(`window.setMarkers && window.setMarkers(${json}); true;`);
    },
  }), []);

  // RN → WV 주입 (배열로 정규화)
  useEffect(() => {
    const arr = normalizeMarkers(markers);
    const json = JSON.stringify(arr);
    lastMarkersJsonRef.current = json;
    if (__DEV__) console.log('[RN->WV] markers len=', arr.length, ' first=', arr[0]);
    if (webRef.current) {
      webRef.current.injectJavaScript(`window.setMarkers && window.setMarkers(${json}); true;`);
    }
  }, [markers]);

  return (
    <WebView
      ref={webRef}
      originWhitelist={['*']}
      source={{ html, baseUrl: 'https://platepay.local' }} // Kakao 콘솔과 동일 도메인 등록 권장
      javaScriptEnabled
      domStorageEnabled
      geolocationEnabled
      androidLayerType="hardware"     // 📌 하드웨어 가속
      mixedContentMode="always"       // 📌 테스트용(혼합콘텐츠 허용). 운영 전 'compatibility'로 완화 권장
      onMessage={(evt) => {
        try {
          const data = JSON.parse(evt.nativeEvent.data || '{}');

          if (data?.type === 'ready') {
            onReady?.();

            // ready 직후: (선택) 디버그 마커 후 실제 마커 재주입
            const arr = normalizeMarkers(markers);
            const jsonToInject =
              lastMarkersJsonRef.current && lastMarkersJsonRef.current !== '[]'
                ? lastMarkersJsonRef.current
                : JSON.stringify(arr);
            lastMarkersJsonRef.current = jsonToInject;

            if (debugTestMarker) {
              webRef.current?.injectJavaScript(`
                (function(){
                  const test = [{ id:'__debug__', name:'DEBUG', lat:37.5665, lng:126.9780 }];
                  window.setMarkers && window.setMarkers(test);
                  setTimeout(() => { window.setMarkers && window.setMarkers(${jsonToInject}); }, 300);
                })(); true;
              `);
            } else {
              webRef.current?.injectJavaScript(`window.setMarkers && window.setMarkers(${jsonToInject}); true;`);
            }

            if (!didAutoLocateRef.current) {
              const shouldAuto =
                autoLocateOnReady === 'always' ||
                (autoLocateOnReady === 'if-granted' && hasNativeLocationPermission);
              if (shouldAuto) {
                didAutoLocateRef.current = true;
                setTimeout(() => {
                  webRef.current?.injectJavaScript('window.locateMe && window.locateMe(); true;');
                }, 0);
              }
            }
          }

          // 진단/상태 로그
          if (data?.type === 'probeSprite') {
            if (__DEV__) console.log('[PROBE] default sprite load:', data.ok, data);
          }
          if (data?.type === 'setMarkersCalled') {
            if (__DEV__) console.log('[WV] setMarkersCalled length=', data.length, ' first=', data.first);
          }
          if (data?.type === 'markersValidated') {
            if (__DEV__) console.log('[WV] markersValidated valid=', data.count, ' first=', data.first);
          }
          if (data?.type === 'markersSetFromQueue') {
            if (__DEV__) console.log('[WV] markersSetFromQueue count=', data.count);
          }
          if (data?.type === 'highlightMiss') {
            if (__DEV__) console.warn('[WV] highlight missed. id=', data.id);
          }
          if (data?.type === 'jsError') {
            console.warn('[MapViewKakao][JS ERROR]', data);
          }
          if (data?.type === 'markerClick') onMarkerClick?.(data.id);
          if (data?.type === 'locOk') onLocateOk?.(data.coords);
          if (data?.type === 'locError') onLocateError?.(String(data.reason));
        } catch (e) {
          console.warn('WebView onMessage parse fail', e);
        }
      }}
      style={style}
    />
  );
});

export default MapViewKakao;
const s = StyleSheet.create({});
