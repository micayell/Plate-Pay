import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ScrollView,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { ScreenProps } from '../../../app/navigation/RootNavigator';
import { SafeAreaView } from 'react-native-safe-area-context';

const AGREEMENT_ITEMS = [
  { id: 'personalInfo', label: '[필수] 개인정보 수집/이용 동의' },
  { id: 'uniqueId', label: '[필수] 고유식별정보 처리 동의' },
  { id: 'serviceTerms', label: '[필수] 서비스 이용약관 동의' },
  { id: 'locationInfo', label: '[필수] 위치정보 수집/이용 동의' },
];

const Checkbox = ({ checked, label, onPress, isParent = false }) => (
  <Pressable style={styles.checkboxRow} onPress={onPress}>
    <View style={[styles.checkboxBase, isParent && styles.checkboxParentBase, checked && styles.checkboxChecked]}>
      {checked && <Text style={styles.checkmark}>✓</Text>}
    </View>
    <Text style={[styles.checkboxLabel, isParent && styles.checkboxParentLabel]}>{label}</Text>
    {!isParent && <Text style={styles.chevron}>〉</Text>}
  </Pressable>
);

export default function SignupScreen({ route, navigation }: ScreenProps<'Signup'>) {
  // route.params에서 authType 대신 memberInfo 객체 전체를 받아옵니다.
  const { memberInfo } = route.params;
  const authType = memberInfo.loginType; // memberInfo에서 로그인 타입을 가져옵니다.

  const [agreements, setAgreements] = useState(
    AGREEMENT_ITEMS.reduce((acc, item) => ({ ...acc, [item.id]: false }), {})
  );
  const [allAgreed, setAllAgreed] = useState(false);

  const [name, setName] = useState('');
  const [phone1, setPhone1] = useState('010');
  const [phone2, setPhone2] = useState('');

  const isSsafyLogin = authType === 'ssafy';

  useEffect(() => {
    // 전달받은 memberInfo를 사용해 이름 또는 닉네임의 초기값을 설정합니다.
    if (isSsafyLogin) {
      setName(memberInfo.nickname || '');
    } else {
      setName(memberInfo.name || '');
    }
  }, [memberInfo, isSsafyLogin]);

  useEffect(() => {
    const allItemsChecked = Object.values(agreements).every(Boolean);
    if (allItemsChecked !== allAgreed) {
      setAllAgreed(allItemsChecked);
    }
  }, [agreements, allAgreed]);

  const toggleAllAgreements = () => {
    const nextValue = !allAgreed;
    setAllAgreed(nextValue);
    const newAgreements = {};
    AGREEMENT_ITEMS.forEach(item => {
      newAgreements[item.id] = nextValue;
    });
    setAgreements(newAgreements);
  };

  const toggleAgreement = (id) => {
    setAgreements(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleSubmit = () => {
    const phoneNum = phone1 + phone2;
    const isSsafy = authType === 'ssafy';

    // PinSetup 화면으로 이동할 때, 입력받은 이름/닉네임과 전화번호를 함께 전달합니다.
    navigation.navigate('PinSetup', {
      name: isSsafy ? memberInfo.name : name,
      nickname: isSsafy ? name : memberInfo.nickname, // SSAFY 로그인의 경우 입력값이 닉네임이 됩니다.
      phoneNum: phoneNum,
    });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" />
      <KeyboardAvoidingView 
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 100 }}>
          <Text style={styles.title}>약관에 동의해주세요.</Text>
          
          <View style={styles.agreementSection}>
            <Checkbox
              checked={allAgreed}
              label="전체동의"
              onPress={toggleAllAgreements}
              isParent
            />
            <View style={styles.divider} />
            {AGREEMENT_ITEMS.map(item => (
              <Checkbox
                key={item.id}
                checked={agreements[item.id]}
                label={item.label}
                onPress={() => toggleAgreement(item.id)}
              />
            ))}
          </View>

          <View style={styles.formSection}>
            <Text style={styles.sectionTitle}>개인정보 입력</Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                {isSsafyLogin ? '닉네임' : '이름'}
              </Text>
              <TextInput
                style={styles.input}
                value={name}
                onChangeText={setName}
                placeholder={
                  isSsafyLogin ? '닉네임을 입력하세요' : '이름을 입력하세요'
                }
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>휴대폰</Text>
              <View style={styles.phoneInputContainer}>
                <TextInput
                  style={[styles.input, styles.phoneInputPrefix]}
                  value={phone1}
                  onChangeText={setPhone1}
                  keyboardType="number-pad"
                  maxLength={3}
                />
                <TextInput
                  style={[styles.input, styles.phoneInputSuffix]}
                  value={phone2}
                  onChangeText={setPhone2}
                  placeholder="나머지번호 입력"
                  keyboardType="number-pad"
                />
              </View>
            </View>
          </View>
        </ScrollView>
        <View style={styles.buttonContainer}>
          <Pressable
            style={styles.submitButton}
            onPress={handleSubmit} // 기존 navigation.navigate('PinSetup')을 handleSubmit 함수로 변경
          >
            <Text style={styles.submitButtonText}>확인</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FFFFFF' },
  container: { flex: 1, paddingHorizontal: 24, paddingTop: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 24 },
  
  agreementSection: { marginBottom: 40 },
  checkboxRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12 },
  checkboxBase: {
    width: 20, height: 20, borderRadius: 4, borderWidth: 1,
    borderColor: '#A0A0A0', marginRight: 12, justifyContent: 'center', alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  checkboxParentBase: { width: 24, height: 24, borderRadius: 12 },
  checkboxChecked: { backgroundColor: '#333333', borderColor: '#333333' },
  checkmark: { color: 'white', fontSize: 12, fontWeight: 'bold' },
  checkboxLabel: { fontSize: 16, color: '#333333' },
  checkboxParentLabel: { fontSize: 18, fontWeight: '500' },
  chevron: { marginLeft: 'auto', color: '#A0A0A0', fontSize: 16 },
  divider: { height: 1, backgroundColor: '#E0E0E0', marginVertical: 8 },
  
  formSection: {},
  sectionTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  inputGroup: { marginBottom: 24 },
  inputLabel: { fontSize: 14, color: '#808080', marginBottom: 8 },
  input: {
    height: 50, fontSize: 18, borderBottomWidth: 1,
    borderBottomColor: '#D0D0D0', paddingHorizontal: 4,
    backgroundColor: '#F7F7F7', borderRadius: 4, paddingLeft: 10,
  },
  phoneInputContainer: { flexDirection: 'row' },
  phoneInputPrefix: { width: 80, marginRight: 12, textAlign: 'center' },
  phoneInputSuffix: { flex: 1 },
  
  buttonContainer: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    paddingHorizontal: 24, paddingBottom: 24, paddingTop: 12,
    backgroundColor: '#FFFFFF',
  },
  submitButton: {
    backgroundColor: '#007AFF', height: 56, borderRadius: 12,
    justifyContent: 'center', alignItems: 'center',
  },
  submitButtonText: { color: 'white', fontSize: 18, fontWeight: 'bold' },
});
