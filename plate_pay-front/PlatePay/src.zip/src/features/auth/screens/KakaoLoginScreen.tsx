import React, { useRef, useState } from 'react';
import { StyleSheet, View, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';
import { ScreenProps } from '../../../app/navigation/RootNavigator';
import { useAuthStore } from '../../../shared/state/authStore';
import { OAUTH_BASE_URL } from '../../../shared/api/api';
import { SafeAreaView } from 'react-native-safe-area-context';
// import BottomTabNavigator from '../../../app/navigation/BottomTabNavigator';

const KakaoLoginScreen = ({ navigation }: ScreenProps<'KakaoLogin'>) => {
  const { setAuthData } = useAuthStore();
  const [isLoading, setIsLoading] = useState(false);
  const webViewRef = useRef<WebView>(null);
  const kakaoLoginUrl = `${OAUTH_BASE_URL}/oauth2/authorization/kakao`;

  const handleMessage = (event: any) => {
    setIsLoading(true);
    try {
      const response = JSON.parse(event.nativeEvent.data);

      if (response.success === true && response.data.accessToken) {
        setAuthData({
          accessToken: response.data.accessToken,
          refreshToken: response.data.refreshToken,
          memberInfo: response.data.memberInfo,
          isLoggedIn: true,
        });

        // statusCode를 확인하여 분기 처리
        if (response.statusCode === 201) {
          // 201: 신규 사용자 -> 회원가입 화면으로 이동
          navigation.replace('Signup', {
            memberInfo: response.data.memberInfo,
          });
        } else {
          // 200 (또는 기타): 기존 사용자 -> 홈 화면으로 이동
          navigation.replace('MainApp');
        }
      } else {
        // 로그인 실패 또는 예외 케이스 처리
        setIsLoading(false);
        // TODO: 사용자에게 에러 알림 표시
      }
    } catch (error) {
      // JSON 파싱 실패는 최종 응답이 아니므로 무시
      setIsLoading(false);
    }
  };

  // 모든 페이지 로딩 완료 시마다 실행될 스크립트
  const scriptToInject = `
    (function() {
      try {
        const pre = document.querySelector('pre');
        const content = pre ? pre.textContent : document.body.innerText;
        // 내용이 JSON 형태인지 먼저 파싱 시도
        JSON.parse(content);

        // 파싱에 성공했다면, 이건 우리가 찾는 JSON 응답 페이지임.
        // 사용자에게 보이지 않도록 즉시 페이지 내용을 숨기고,
        // 데이터는 앱으로 전달한다.
        document.body.style.display = 'none';
        window.ReactNativeWebView.postMessage(content);
      } catch (e) {
        // 파싱에 실패했다면, 일반 웹페이지(예: 카카오 로그인창)이므로 아무것도 하지 않음.
      }
      return true;
    })();
  `;

  // 화면 비율 등을 맞추기 위한 스크립트
  const injectedJavaScriptBeforeContentLoaded = `
    const meta = document.createElement('meta');
    meta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
    meta.setAttribute('name', 'viewport');
    document.getElementsByTagName('head')[0].appendChild(meta);
    true;
  `;

  return (
    <SafeAreaView style={styles.container}>
      {isLoading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#007AFF" />
        </View>
      )}
      <WebView
        ref={webViewRef}
        source={{ uri: kakaoLoginUrl }}
        onMessage={handleMessage}
        // 페이지 로딩 시마다 스크립트 주입
        injectedJavaScript={scriptToInject}
        onError={syntheticEvent => {
          const { nativeEvent } = syntheticEvent;
          console.error('WebView 에러:', nativeEvent);
        }}
        startInLoadingState={true}
        renderLoading={() => (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#007AFF" />
          </View>
        )}
        incognito={true}
        cacheEnabled={false}
        injectedJavaScriptBeforeContentLoaded={
          injectedJavaScriptBeforeContentLoaded
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
  },
});

export default KakaoLoginScreen;
