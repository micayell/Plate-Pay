// src/features/wallet/components/CardCarousel.tsx
import React from 'react';
import {
  ScrollView,
  View,
  StyleSheet,
  Dimensions,
  NativeSyntheticEvent,
  NativeScrollEvent,
  Pressable,
  Text,
} from 'react-native';
// ✅ 디버깅을 위해 모듈 전체 임포트 후, named/default 자동 선택
import * as WalletCardMod from './WalletCard';
import { useResponsive } from '../../../shared/ui/responsive';

// named / default 어느 쪽이든 가져오도록 안전 처리
const WalletCard: any =
  (WalletCardMod as any)?.WalletCard ?? (WalletCardMod as any)?.default;

type AccountItem = {
  accountId?: number;           // 🔽 키 안정성 위해 optional 추가 (넘겨주면 사용)
  title: string;
  owner: string;
  last4: string;
  gradient: string[];
};

type Props = {
  onIndexChange?: (idx: number) => void; // 실제 계좌 인덱스 전달
  onPressAdd?: () => void;
  items?: AccountItem[];
  /** 현재 슬라이드 정보 전달 (account/add) */
  onActiveSlideChange?: (info: {
    index: number;
    type: 'account' | 'add';
  }) => void;

  // 🔽 카드 내부 모달 확정 이벤트를 상위로 올려보내기
  onRenameAt?: (index: number, nextAlias: string) => void;
  onDeleteAt?: (index: number) => void;
};

export const CardCarousel: React.FC<Props> = ({
  onIndexChange,
  onPressAdd,
  items: externalItems,
  onActiveSlideChange,
  onRenameAt,
  onDeleteAt,
}) => {
  const { s, bp } = useResponsive();

  // 🔎 어떤 식으로 export되었는지 콘솔에 남김
  React.useEffect(() => {
    try {
      // eslint-disable-next-line no-console
      console.log('[CardCarousel] WalletCard exports =', Object.keys(WalletCardMod || {}));
      // eslint-disable-next-line no-console
      console.log('[CardCarousel] WalletCard typeof  =', typeof WalletCard);
    } catch {}
  }, []);

  const screenWidth = Dimensions.get('window').width || 375;
  const cardWidth = bp === 'tablet' ? s(320) || 320 : s(280) || 280;
  const cardHeight = bp === 'tablet' ? s(200) || 200 : s(170) || 170;
  const cardGap = s(16) || 16;
  const sidePadding = Math.max(0, (screenWidth - cardWidth) / 2);
  const snap = Math.max(1, cardWidth + cardGap);
  const radius = s(20) || 20;

  const baseItems: AccountItem[] = externalItems ?? [
    {
      title: 'Vacation',
      owner: '윤경호',
      last4: '1121',
      gradient: ['#010813', '#050F1D', '#10213D', '#132A4E', '#1F4785'],
    },
    {
      title: 'Clothes',
      owner: '윤경호',
      last4: '3421',
      gradient: ['#081411', '#102E27', '#1F5F52', '#2E8E79', '#77D3BD'],
    },
    {
      title: 'Daily',
      owner: '윤경호',
      last4: '9012',
      gradient: ['#1F2A44', '#0B1226'],
    },
  ];

  // 최대 4개 제한
  const accounts = baseItems.slice(0, 4);
  // 3개 미만이면 추가 카드 노출
  const showAddCard = accounts.length < 3;
  const totalSlides = accounts.length + (showAddCard ? 1 : 0);

  const onMomentumEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const x = e.nativeEvent.contentOffset?.x ?? 0;
    const raw = Math.round((x - sidePadding) / snap);
    const slideIdx = Math.max(0, Math.min(totalSlides - 1, raw));

    const isAdd = showAddCard && slideIdx === totalSlides - 1;
    const effectiveIdx = Math.min(slideIdx, accounts.length - 1);

    // 실제 계좌 인덱스 전달
    if (accounts.length > 0) {
      onIndexChange?.(Math.max(0, effectiveIdx));
    }

    // 슬라이드 타입 전달
    onActiveSlideChange?.({
      index: isAdd ? effectiveIdx : slideIdx,
      type: isAdd ? 'add' : 'account',
    });
  };

  // WalletCard가 쓸 수 있는 타입인지 체크
  const isWalletCardUsable =
    WalletCard && (typeof WalletCard === 'function' || typeof WalletCard === 'object');

  return (
    <View style={{ height: cardHeight + (s(10) || 10) }}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        decelerationRate="fast"
        snapToInterval={snap}
        snapToAlignment="start"
        contentContainerStyle={{
          paddingLeft: sidePadding,
          paddingRight: sidePadding,
        }}
        onMomentumScrollEnd={onMomentumEnd}
        keyboardShouldPersistTaps="handled"
      >
        {/* 실제 계좌 카드 */}
        {accounts.map((it, idx) => (
          <View
            key={`acc-${it.accountId ?? idx}`}  // 🔽 가능한 경우 id로 key 고정
            style={{ marginRight: idx === totalSlides - 1 ? 0 : cardGap }}
          >
            {isWalletCardUsable ? (
              <WalletCard
                {...it}
                size={{ width: cardWidth, height: cardHeight }}
                // 🔽 카드 내부 모달 확정 시 상위로 전달
                onRename={(name: string) => onRenameAt?.(idx, name)}
                onDelete={() => onDeleteAt?.(idx)}
              />
            ) : (
              // ⛑️ WalletCard가 undefined일 때 죽지 않도록 임시 placeholder
              <View
                style={[
                  styles.addCard,
                  {
                    width: cardWidth,
                    height: cardHeight,
                    borderRadius: radius,
                    backgroundColor: '#E5E7EB',
                  },
                ]}
              >
                <Text style={{ color: '#111827', fontWeight: '700' }}>
                  WalletCard undefined
                </Text>
                <Text style={{ color: '#6B7280', fontSize: 12, marginTop: 4 }}>
                  check export/import or native link
                </Text>
              </View>
            )}
          </View>
        ))}

        {/* 추가 카드 (3개 미만일 때만) */}
        {showAddCard && (
          <View key="add-card" style={{ marginRight: 0 }}>
            <Pressable
              onPress={onPressAdd}
              android_ripple={{ color: 'rgba(0,0,0,0.06)', borderless: false }}
              style={[
                styles.addCard,
                { width: cardWidth, height: cardHeight, borderRadius: radius },
              ]}
            >
              <View style={styles.addInner}>
                <Text style={styles.addPlus}>+</Text>
                <Text style={styles.addLabel}>계좌 등록하기</Text>
              </View>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  addCard: {
    overflow: 'hidden',
    backgroundColor: '#F3F4F6',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#E5E7EB',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  addInner: { alignItems: 'center', justifyContent: 'center' },
  addPlus: {
    fontSize: 28,
    lineHeight: 32,
    color: '#6B7280',
    fontWeight: '700',
    marginBottom: 6,
  },
  addLabel: { fontSize: 13, color: '#6B7280', fontWeight: '600' },
});
