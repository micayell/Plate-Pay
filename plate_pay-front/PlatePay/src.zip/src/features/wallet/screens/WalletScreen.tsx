// src/features/wallet/screens/WalletScreen.tsx
import React, { useMemo, useState, useCallback, useEffect, useRef } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { CardCarousel } from '../components/CardCarousel';
import { AccountDonutChart } from '../components/AccountDonutChart';
import { useTabStore } from '../../../shared/state/tabStore';
import { YearMonthModal } from '../components/modals/YearMonthModal';
import { useIsFocused, useNavigation } from '@react-navigation/native';

// API
import {
  getAccountsOnce,
  refreshAccounts,         // ✅ 포커스 때 강제 새로고침용
  setPrimaryAccount,
  renameAccount,
  deleteAccount,
  getAccountStats,
  type AccountStat,
} from '../api/accountApi';

type UiAccount = {
  accountId: number;
  title: string;
  owner: string;
  last4: string;
  gradient: string[];
  stats: { label: string; value: number; color: string }[];
};

const PRIMARY = '#0064FF';

const CATEGORY_COLORS: Record<string, string> = {
  CAFE: '#F59E0B',
  RESTAURANT: '#EF4444',
  MART: '#10B981',
  CONVENIENCE: '#3B82F6',
  TRANSPORT: '#8B5CF6',
  ETC: '#6B7280',
};
const PALETTE = ['#4F46E5', '#0F172A', '#2E7D6B', '#F59E0B', '#EF4444', '#10B981', '#3B82F6', '#8B5CF6'];

function toChartStats(raw: AccountStat[]): UiAccount['stats'] {
  if (!raw?.length) return [{ label: '데이터 없음', value: 100, color: '#9CA3AF' }];
  const total = raw.reduce((s, r) => s + (r.totalCost || 0), 0) || 1;
  let sum = 0;
  const out = raw.map((r, i) => {
    const pct = Math.round(((r.totalCost || 0) / total) * 100);
    sum += pct;
    const key = (r.storeType || '').toUpperCase();
    const color = CATEGORY_COLORS[key] || PALETTE[i % PALETTE.length];
    return { label: key || '기타', value: pct, color };
  });
  const diff = 100 - sum;
  out[out.length - 1].value += diff;
  out.forEach(s => { if (s.value < 0) s.value = 0; });
  return out;
}

export default function WalletScreen() {
  // 탭바 hide/show
  const hide = useTabStore(s => s.hide);
  const show = useTabStore(s => s.show);
  useEffect(() => { hide(); return () => show(); }, []);

  const nav = useNavigation<any>();
  const isFocused = useIsFocused();           // ✅ 화면 포커스 감지

  const [currentIndex, setCurrentIndex] = useState(0);
  const [primaryIndex, setPrimaryIndex] = useState(0);
  const [isAddSlideActive, setIsAddSlideActive] = useState(false);

  const now = new Date();
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [ymVisible, setYmVisible] = useState(false);

  const [settingPrimary, setSettingPrimary] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);
  const statsCacheRef = useRef<Map<string, UiAccount['stats']>>(new Map());

  const initialAccounts: UiAccount[] = useMemo(
    () => [{
      accountId: 1,
      title: 'Vacation',
      owner: '윤경호',
      last4: '1234',
      gradient: ['#010813', '#050F1D', '#10213D', '#132A4E', '#1F4785'],
      stats: [
        { label: 'Expenses', value: 46, color: '#4F46E5' },
        { label: 'Income',   value: 32, color: '#0F172A' },
        { label: 'Savings',  value: 22, color: '#2E7D6B' },
      ],
    }],
    [],
  );

  const [accounts, setAccounts] = useState<UiAccount[]>(initialAccounts);

  const current = accounts[currentIndex] ?? accounts[0];
  const isPrimary = accounts.length > 0 && currentIndex === primaryIndex;
  const ymLabel = `${selectedYear}.${String(selectedMonth).padStart(2, '0')}`;

  // ✅ 화면이 포커스될 때마다 목록 새로고침 + 캐시 리셋
  useEffect(() => {
    if (!isFocused) return;
    let cancelled = false;

    const load = async () => {
      try {
        statsCacheRef.current.clear(); // 통계 캐시 비우기(항상 최신)
        const list = await refreshAccounts(); // 강제 최신 목록
        if (cancelled) return;

        const gradients = [
          ['#010813', '#050F1D', '#10213D', '#132A4E', '#1F4785'],
          ['#2E7D6B', '#1F5F52'],
          ['#4F46E5', '#3C34B1'],
          ['#0F172A', '#0A0F1C'],
        ];

        const mapped: UiAccount[] = (list ?? []).map((acc: any, idx: number) => ({
          accountId: acc.accountId,
          title: acc.accountName,
          owner: acc.bankName ?? '윤경호',
          last4: String(acc.accountNo ?? '').slice(-4),
          gradient: gradients[idx % gradients.length],
          stats: [
            { label: 'Expenses', value: 46, color: '#4F46E5' },
            { label: 'Income',   value: 32, color: '#0F172A' },
            { label: 'Savings',  value: 22, color: '#2E7D6B' },
          ],
        }));

        setAccounts(prev => mapped.length ? mapped : prev);
        // 인덱스 범위 보정
        setCurrentIndex(ci => Math.min(ci, Math.max(0, mapped.length - 1)));
        setPrimaryIndex(pi => Math.min(pi, Math.max(0, mapped.length - 1)));
      } catch (e) {
        console.error('📥 포커스 시 계좌 로드 실패:', e);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [isFocused]);

  const onPickPrimary = useCallback(async () => {
    const selected = accounts[currentIndex];
    if (!selected || settingPrimary) return;
    try {
      setSettingPrimary(true);
      await setPrimaryAccount(selected.accountId);
      setPrimaryIndex(currentIndex);
    } catch (e) {
      console.error('주 계좌 변경 실패:', e);
    } finally {
      setSettingPrimary(false);
    }
  }, [accounts, currentIndex, settingPrimary]);

  const handlePressAdd = useCallback(() => {
    nav.navigate('AddAccount', {
      ownerName: current?.owner ?? '윤경호',
      onSubmit: (acc: { title: string; owner: string; last4: string; gradient: string[] }) => {
        setAccounts(prev => {
          const nextId = Math.max(0, ...prev.map(p => p.accountId)) + 1;
          return prev.concat({
            ...acc,
            accountId: nextId,
            stats: [
              { label: 'Expenses', value: 40, color: '#4F46E5' },
              { label: 'Income',   value: 40, color: '#0F172A' },
              { label: 'Savings',  value: 20, color: '#2E7D6B' },
            ],
          });
        });
      },
    });
  }, [nav, current]);

  const handleRenameAt = useCallback(async (index: number, nextAlias: string) => {
    const target = accounts[index];
    if (!target) return;
    const trimmed = (nextAlias ?? '').trim();
    if (!trimmed || trimmed === target.title) return;
    const prevTitle = target.title;
    setAccounts(prev => prev.map((a, i) => (i === index ? { ...a, title: trimmed } : a)));
    try {
      await renameAccount(target.accountId, trimmed);
    } catch (e) {
      console.error('별명 변경 실패:', e);
      setAccounts(prev => prev.map((a, i) => (i === index ? { ...a, title: prevTitle } : a)));
    }
  }, [accounts]);

  const handleDeleteAt = useCallback(async (index: number) => {
    const target = accounts[index];
    if (!target) return;

    const prevAccounts = accounts;
    const prevCur = currentIndex;
    const prevPri = primaryIndex;

    const nextAccounts = prevAccounts.filter((_, i) => i !== index);
    setAccounts(nextAccounts);

    let nextCur = prevCur;
    if (nextAccounts.length === 0) nextCur = 0;
    else if (prevCur > index) nextCur = prevCur - 1;
    else if (prevCur === index) nextCur = Math.min(index, nextAccounts.length - 1);
    setCurrentIndex(nextCur);

    let nextPri = prevPri;
    if (nextAccounts.length === 0) nextPri = 0;
    else if (prevPri > index) nextPri = prevPri - 1;
    else if (prevPri === index) nextPri = 0;
    setPrimaryIndex(nextPri);

    try { await deleteAccount(target.accountId); }
    catch (e) {
      console.error('계좌 삭제 실패, 롤백:', e);
      setAccounts(prevAccounts);
      setCurrentIndex(prevCur);
      setPrimaryIndex(prevPri);
    }
  }, [accounts, currentIndex, primaryIndex]);

  // 📊 카드 전환/연월 변경 시 통계 호출
  useEffect(() => {
    if (isAddSlideActive) return;
    const acct = accounts[currentIndex];
    if (!acct) return;

    const key = `${acct.accountId}:${selectedYear}-${selectedMonth}`;
    const cached = statsCacheRef.current.get(key);
    if (cached) {
      setAccounts(prev => {
        const idx = prev.findIndex(a => a.accountId === acct.accountId);
        if (idx < 0 || prev[idx].stats === cached) return prev;
        const next = [...prev];
        next[idx] = { ...next[idx], stats: cached };
        return next;
      });
      return;
    }

    let cancelled = false;
    setStatsLoading(true);
    (async () => {
      try {
        const raw = await getAccountStats(acct.accountId, { year: selectedYear, month: selectedMonth });
        const stats = toChartStats(raw);
        if (cancelled) return;
        statsCacheRef.current.set(key, stats);
        setAccounts(prev => {
          const idx = prev.findIndex(a => a.accountId === acct.accountId);
          if (idx < 0 || prev[idx].stats === stats) return prev;
          const next = [...prev];
          next[idx] = { ...next[idx], stats };
          return next;
        });
      } catch (e) {
        console.error('계좌별 통계 조회 실패:', e);
      } finally {
        if (!cancelled) setStatsLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [currentIndex, selectedYear, selectedMonth, isAddSlideActive, accounts]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.iconBtn} />
        <Text style={styles.headerTitle}>Wallet</Text>
        <Pressable style={styles.iconBtn}><Text style={styles.icon}>👤</Text></Pressable>
      </View>

      <CardCarousel
        onIndexChange={setCurrentIndex}
        onPressAdd={handlePressAdd}
        items={accounts}
        onActiveSlideChange={({ type }) => setIsAddSlideActive(type === 'add')}
        onRenameAt={handleRenameAt}
        onDeleteAt={handleDeleteAt}
      />

      {!isAddSlideActive && accounts.length > 0 && (
        isPrimary ? (
          <View style={[styles.cta, { backgroundColor: '#9CA3AF' }]}>
            <Text style={styles.ctaText}>사용중</Text>
          </View>
        ) : (
          <Pressable
            style={[styles.cta, settingPrimary && { opacity: 0.7 }]}
            onPress={onPickPrimary}
            disabled={settingPrimary}
            android_ripple={{ color: 'rgba(255,255,255,0.2)' }}
          >
            <Text style={styles.ctaText}>{settingPrimary ? '설정 중…' : '주계좌 선택'}</Text>
          </Pressable>
        )
      )}

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>통계</Text>
          {!isAddSlideActive && (
            <Pressable onPress={() => setYmVisible(true)} hitSlop={8}>
              <Text style={styles.sectionSub}>{ymLabel}</Text>
            </Pressable>
          )}
        </View>

        {!isAddSlideActive && current && (
          <>
            {statsLoading ? (
              <Text style={{ textAlign: 'center', color: '#6B7280', marginTop: 8 }}>통계 불러오는 중…</Text>
            ) : (
              <>
                <AccountDonutChart data={current.stats} size={160} donutRadius={36} />
                <View style={{ height: 12 }} />
                {current.stats.map(s => (
                  <View key={s.label} style={styles.legendRow}>
                    <View style={[styles.dot, { backgroundColor: s.color }]} />
                    <Text style={styles.legendLabel}>{s.label}</Text>
                    <View style={{ flex: 1 }} />
                    <Text style={styles.legendVal}>{s.value}%</Text>
                  </View>
                ))}
              </>
            )}
          </>
        )}
      </View>

      <YearMonthModal
        visible={ymVisible}
        year={selectedYear}
        month={selectedMonth}
        onClose={() => setYmVisible(false)}
        onConfirm={(y, m) => {
          setSelectedYear(y);
          setSelectedMonth(m);
          setYmVisible(false);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    paddingTop: 12, paddingHorizontal: 16, paddingBottom: 5, height: 150,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  iconBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  icon: { fontSize: 16 },
  headerTitle: { fontSize: 18, fontWeight: '700' },

  cta: {
    marginHorizontal: 24, marginTop: 30, height: 55, borderRadius: 25, padding: 14,
    alignItems: 'center', justifyContent: 'center', alignSelf: 'center', backgroundColor: PRIMARY, width: 160,
  },
  ctaText: { color: 'white', fontSize: 16, fontWeight: '700' },

  section: { paddingHorizontal: 40, paddingTop: 40 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  sectionTitle: { fontSize: 18, fontWeight: '700' },
  sectionSub: { color: '#6B7280' },

  legendRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  legendLabel: { fontSize: 14, color: '#111827', fontWeight: '700' },
  legendVal: { fontWeight: '600' },
});
