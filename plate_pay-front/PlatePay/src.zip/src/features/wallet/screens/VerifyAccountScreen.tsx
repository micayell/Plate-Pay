import React, { useMemo, useRef, useState, useEffect } from 'react';
import { View, Text, StyleSheet, Pressable, TextInput, Platform } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';

type RouteParams = {
  accountDisplay: string;
  onVerified?: () => void;
  // 선택: 서버/상위에서 검증 함수 주면 사용 (동기/비동기 모두 지원)
  validateCode?: (code: string) => boolean | Promise<boolean>;
};

const PRIMARY = '#0064FF';
const MAX_LEN = 4;

export default function VerifyAccountScreen() {
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const { accountDisplay, onVerified, validateCode } = (route.params ?? {}) as RouteParams;

  const [values, setValues] = useState<string[]>(Array(MAX_LEN).fill(''));
  const [focusedIndex, setFocusedIndex] = useState(0);
  const [complete, setComplete] = useState(false);
  const [error, setError] = useState<string | null>(null); // ❗실패 라벨 제어
  const inputs = useRef<Array<TextInput | null>>([]);

  const canSubmit = useMemo(() => values.every(v => v.length === 1), [values]);

  // 완료 화면 보여주고 자동 복귀
  useEffect(() => {
    if (complete) {
      onVerified?.();
      const timer = setTimeout(() => {
        if (nav.canGoBack()) nav.pop(2);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [complete, nav, onVerified]);

  const handleBack = () => nav.goBack();

  // 현재 코드 문자열
  const getCode = () => values.join('');

  // 코드 검증
  const verify = async () => {
    const code = getCode();
    if (!validateCode) {
      // 데모/기본: 4자리면 성공으로 처리
      return code.length === MAX_LEN;
    }
    try {
      const res = await Promise.resolve(validateCode(code));
      return !!res;
    } catch {
      return false;
    }
  };

  const handleSubmit = async () => {
    if (!canSubmit) return;
    setError(null);
    const ok = await verify();
    if (ok) {
      setComplete(true);
    } else {
      // 실패 처리: 입력 초기화 + 에러 라벨 노출 + 포커스 리셋
      setValues(Array(MAX_LEN).fill(''));
      setFocusedIndex(0);
      // 살짝 딜레이 후 포커스(리렌더 타이밍 보정)
      requestAnimationFrame(() => inputs.current[0]?.focus());
      setError('인증번호가 올바르지 않습니다. 다시 입력해 주세요.');
    }
  };

  // 텍스트 변경
  const onChangeAt = (index: number, text: string) => {
    const filtered = text.replace(/[^0-9]/g, '');
    const next = [...values];
    next[index] = filtered.charAt(0) || '';
    setValues(next);
    setError(null); // 입력 중 에러 라벨 숨김

    if (filtered && index < MAX_LEN - 1) {
      inputs.current[index + 1]?.focus();
      setFocusedIndex(index + 1);
    }

    if (next.every(v => v.length === 1)) {
      // 자동 제출 (버튼은 유지)
      setTimeout(handleSubmit, 50);
    }
  };

  // 백스페이스 처리
  const onKeyPressAt = (index: number, e: any) => {
    if (e.nativeEvent.key === 'Backspace') {
      if (values[index]) {
        const next = [...values];
        next[index] = '';
        setValues(next);
      } else if (index > 0) {
        inputs.current[index - 1]?.focus();
        setFocusedIndex(index - 1);
        const next = [...values];
        next[index - 1] = '';
        setValues(next);
      }
    }
  };

  // 완료 화면
  if (complete) {
    return (
      <View style={s.completeContainer}>
        <View style={s.checkCircle}>
          <Text style={s.checkMark}>✓</Text>
        </View>
        <Text style={s.completeText}>등록 완료!</Text>
      </View>
    );
  }

  return (
    <View style={s.container}>
      {/* WalletScreen 스타일 헤더 */}
      <View style={s.header}>
        <Pressable style={s.iconBtn} onPress={handleBack} hitSlop={8}>
          <Text style={s.icon}>{'<'}</Text>
        </Pressable>
        <Text style={s.headerTitle}>계좌 인증</Text>
        <View style={s.iconBtn} />
      </View>

      <View style={s.body}>
        <Text style={s.title}>1원을 보냈습니다.</Text>
        <Text style={s.subtitle}>입금내역에 표시된 숫자를 입력해주세요.</Text>

        <View style={s.accountPill}>
          <Text style={s.accountText} numberOfLines={1}>
            {accountDisplay || 'KB국민 123-123455-123123-123'}
          </Text>
        </View>

        <View style={s.otpWrap}>
          {Array.from({ length: MAX_LEN }).map((_, i) => (
            <TextInput
              key={i}
              ref={ref => (inputs.current[i] = ref)}
              value={values[i]}
              onChangeText={t => onChangeAt(i, t)}
              onKeyPress={e => onKeyPressAt(i, e)}
              onFocus={() => setFocusedIndex(i)}
              keyboardType="number-pad"
              {...(Platform.OS !== 'web' ? { inputMode: 'numeric' as any } : {})}
              maxLength={1}
              style={[
                s.otpInput,
                (focusedIndex === i || values[i]) && s.otpInputActive, // 포커스/입력된 칸 파랑 테두리
                error && s.otpInputError, // 에러 시 보더 강조(옵션)
              ]}
              textAlign="center"
              autoFocus={i === 0}
              caretHidden
            />
          ))}
        </View>

        {/* 실패 라벨 */}
        {!!error && <Text style={s.errorText}>{error}</Text>}
      </View>

      {/* 하단 인증 버튼 복원 */}
      <View style={s.footer}>
        <Pressable
          style={[s.submitBtn, canSubmit ? s.submitBtnEnabled : s.submitBtnDisabled]}
          disabled={!canSubmit}
          onPress={handleSubmit}
          android_ripple={{ color: 'rgba(255,255,255,0.25)' }}
        >
          <Text style={s.submitText}>인증</Text>
        </Pressable>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },

  header: {
    height: 150,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#111' },
  iconBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 18 },
  icon: { fontSize: 18, color: '#111' },

  body: { flex: 1, paddingHorizontal: 20, alignItems: 'center' },
  title: { marginTop: 12, fontSize: 22, fontWeight: '800', color: '#111', textAlign: 'center' },
  subtitle: { marginTop: 8, fontSize: 14, color: '#9CA3AF', textAlign: 'center' },

  accountPill: {
    marginTop: 16,
    paddingHorizontal: 16,
    height: 40,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'stretch',
  },
  accountText: { fontSize: 14, color: '#111827', fontWeight: '700' },

  otpWrap: {
    marginTop: 28,
    flexDirection: 'row',
    gap: 18,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  otpInput: {
    width: 56,
    height: 56,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    fontSize: 20,
    fontWeight: '700',
    color: '#111',
  },
  otpInputActive: { borderColor: PRIMARY },
  otpInputError: {}, // 필요하면 에러 시 색/쉐도우 추가 가능

  // 실패 라벨
  errorText: { marginTop: 10, color: '#EF4444', fontWeight: '600', fontSize: 12 },

  footer: { paddingHorizontal: 24, paddingBottom: 24, paddingTop: 10 },
  submitBtn: {
    height: 56,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitBtnEnabled: { backgroundColor: PRIMARY },
  submitBtnDisabled: { backgroundColor: '#A5B4FC' },
  submitText: { color: '#FFF', fontWeight: '800', fontSize: 16 },

  // 등록 완료 화면
  completeContainer: {
    flex: 1,
    backgroundColor: PRIMARY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  checkMark: { fontSize: 40, color: PRIMARY },
  completeText: { color: 'white', fontSize: 28, fontWeight: 'bold' },
});
