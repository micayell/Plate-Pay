import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  Dimensions,
  ActivityIndicator,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {
  startVehicleRegistration,
  confirmVehicleRegistration,
} from '../../../shared/api/carApi';
import { VehicleRegistrationRequest, VehicleRegistrationResponse } from '../../../types/type';


const StepIndicator = ({ currentStep }: { currentStep: number }) => {
  return (
    <View style={styles.stepIndicatorContainer}>
      {[1, 2, 3].map(step => (
        <React.Fragment key={step}>
          <View
            style={[
              styles.step,
              currentStep >= step && styles.stepActive,
              currentStep > step && styles.stepCompleted,
            ]}
          >
            {currentStep > step ? (
              <Icon name="check" size={14} color="#FFF" />
            ) : (
              <Text style={[styles.stepText, currentStep >= step && styles.stepTextActive]}>
                {step}
              </Text>
            )}
          </View>
          {step < 3 && <View style={styles.stepConnector} />}
        </React.Fragment>
      ))}
    </View>
  );
};

const InfoBox = () => (
  <View style={styles.infoBox}>
    <Text style={styles.infoTitle}>차량 소유주 확인</Text>
    <Text style={styles.infoText}>
      입력하신 차량 번호의 소유주 확인을 위해 간단한 인증 절차가 진행됩니다. 차량번호와
      주민등록번호로 본인 확인이 가능합니다.
    </Text>
  </View>
);

const VehicleRegistrationScreen = ({ navigation }) => {
  const [step, setStep] = useState(1);
  const [plateNumber, setPlateNumber] = useState('12가3456');
  const [nickname, setNickname] = useState('');
  const [name, setName] = useState('홍길동');
  const [rrn, setRrn] = useState('000000');
  const [rrnBack, setRrnBack] = useState('');
  const [isLoading, setIsLoading] = useState(false); // 로딩 상태 추가

  // 현재 단계(step)에 따라 헤더의 표시 여부를 동적으로 제어합니다.
  useEffect(() => {
    navigation.setOptions({
      headerShown: step <= 3,
      title: '차량 등록',
      headerBackTitleVisible: false,
    });
  }, [navigation, step]);


  const handleNext = async () => {
    if (step === 2) {
      setIsLoading(true);
      try {
        const registrationData: VehicleRegistrationRequest = {
          name: name,
          nickname: nickname,
          carNo: plateNumber,
          ssn: `${rrn}${rrnBack}`,
        };
        
        // API 호출
        const response = await startVehicleRegistration(registrationData);

        // 성공적으로 응답을 받으면 다음 단계로 이동
        // TODO: response.code 등을 확인하는 로직 추가 필요
        console.log('1차 검증 응답:', response);
        setStep(prev => prev + 1);

      } catch (error) {
        // 에러 발생 시 알림 표시
        Alert.alert('오류', '차량 소유주 확인에 실패했습니다. 입력 정보를 확인해주세요.');
        // 실패 화면으로 이동하거나 현재 화면에 머무를 수 있습니다.
        // setStep(5); 
      } finally {
        setIsLoading(false);
      }
    } else {
      // 1단계 -> 2단계 이동
      setStep(prev => prev + 1);
    }
  };

  // 3단계 '내 차 등록하기' 버튼을 위한 핸들러 추가
  const handleFinalRegistration = async () => {
    setIsLoading(true);
    try {
      await confirmVehicleRegistration();
      // 성공 시, 성공 화면으로 이동
      setStep(4);
    } catch (error) {
      // 실패 시, 에러 알림 후 실패 화면으로 이동
      Alert.alert('등록 실패', '차량 등록 최종 확인에 실패했습니다.');
      setStep(5);
    } finally {
      setIsLoading(false);
    }
  };

  const renderContent = () => {
    switch (step) {
      case 1:
        return (
          <>
            <Text style={styles.title}>차량 번호를 입력하세요</Text>
            <Text style={styles.subtitle}>등록된 차량 번호로 자동 결제가 진행됩니다</Text>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>차량 번호</Text>
              <TextInput
                style={styles.input}
                value={plateNumber}
                onChangeText={setPlateNumber}
                placeholder="12가3456"
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>차량 닉네임</Text>
              <TextInput
                style={styles.input}
                value={nickname}
                onChangeText={setNickname}
                placeholder="차량 닉네임을 입력해주세요."
              />
            </View>

            <InfoBox />
            <TouchableOpacity style={styles.button} onPress={handleNext}>
              <Text style={styles.buttonText}>다음</Text>
            </TouchableOpacity>
          </>
        );
      case 2:
        return (
          <>
            <Text style={styles.title}>주민등록번호를 입력하세요</Text>
            <Text style={styles.subtitle}>차량 소유주를 확인합니다</Text>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>이름</Text>
              <TextInput style={styles.input} value={name} onChangeText={setName} />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>주민등록번호</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  value={rrn}
                  onChangeText={setRrn}
                  keyboardType="number-pad"
                  maxLength={6}
                />
                <Text style={{ marginHorizontal: 10, fontSize: 20 }}>-</Text>
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  value={rrnBack}
                  onChangeText={setRrnBack}
                  keyboardType="number-pad"
                  maxLength={7}
                  secureTextEntry
                />
              </View>
            </View>
            <InfoBox />
            <TouchableOpacity 
              style={[styles.button, isLoading && styles.buttonDisabled]} 
              onPress={handleNext}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#FFF" />
              ) : (
                <Text style={styles.buttonText}>다음</Text>
              )}
            </TouchableOpacity>
          </>
        );
      case 3:
        return (
            <>
              <Text style={styles.title}>카카오 인증</Text>
              <Text style={styles.subtitle}>
                카카오톡에서 인증 요청을 확인하고 승인해 주세요. 인증 완료 후 '내 차 등록하기'
                버튼을 눌러주세요
              </Text>
              <InfoBox />
              {/* 버튼 onPress와 로딩 상태 연결 */}
              <TouchableOpacity
                style={[styles.button, isLoading && styles.buttonDisabled]}
                onPress={handleFinalRegistration}
                disabled={isLoading}>
                {isLoading ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <Text style={styles.buttonText}>내 차 등록하기</Text>
                )}
              </TouchableOpacity>
            </>
          );
      case 4: // Success
        return (
          <View style={styles.resultContainer}>
            <View style={[styles.resultIcon, { backgroundColor: '#007AFF' }]}>
              <Icon name="check" size={50} color="#FFF" />
            </View>
            <Text style={styles.resultTitle}>인증이 완료되었어요!</Text>
            <Text style={styles.resultSubtitle}>
              이제 '홈으로' 버튼을 눌러 진행해 주세요.
            </Text>
            {/* 버튼 동작을 popToTop으로 수정하여 스택의 첫 화면(VehicleScreen)으로 돌아갑니다. */}
            <TouchableOpacity style={styles.button} onPress={() => navigation.popToTop()}>
              <Text style={styles.buttonText}>홈으로</Text>
            </TouchableOpacity>
          </View>
        );
      case 5: // Failure
        return (
          <View style={styles.resultContainer}>
            <View style={[styles.resultIcon, { backgroundColor: '#FF3B30' }]}>
              <Icon name="exclamation" size={50} color="#FFF" />
            </View>
            <Text style={styles.resultTitle}>등록에 실패했어요.</Text>
            <Text style={styles.resultSubtitle}>차량등록 상태가 유효하지 않습니다.</Text>
            <Text style={styles.errorCode}>
              응답코드 : 비정상 차량등록 상태 (소유주 불일치, 정부24 미가입 등)
            </Text>
            <TouchableOpacity style={styles.button} onPress={() => setStep(1)}>
              <Text style={styles.buttonText}>확인</Text>
            </TouchableOpacity>
          </View>
        );
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* 단계 1-3은 스크롤 가능한 뷰, 4-5(결과)는 전체 화면 뷰로 분리 */}
      {step <= 3 ? (
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.contentWrapper}>
            <View>
              <StepIndicator currentStep={step} />
              {renderContent()}
            </View>
            <TouchableOpacity>
              <Text style={styles.footerText}>
                차량 번호 입력에 어려움이 있으신가요? <Text style={{ textDecorationLine: 'underline' }}>도움말 보기</Text>
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      ) : (
        renderContent()
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FFF' },
  container: {
    flexGrow: 1,
    backgroundColor: '#FFF',
    padding: 20,
    paddingBottom: 40, // 하단 여백 추가
  },
  contentWrapper: {
    flex: 1,
    justifyContent: 'space-between',
    minHeight: Dimensions.get('window').height - 150, // 화면 높이에 맞춰 최소 높이 지정
  },
  // Step Indicator
  stepIndicatorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 30,
  },
  step: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#E5E5EA',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFF',
  },
  stepActive: {
    borderColor: '#007AFF',
    backgroundColor: '#007AFF',
  },
  stepCompleted: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
  stepText: {
    color: '#E5E5EA',
    fontWeight: 'bold',
  },
  stepTextActive: {
    color: '#FFF',
  },
  stepConnector: {
    flex: 1,
    height: 2,
    backgroundColor: '#E5E5EA',
    marginHorizontal: -2,
  },
  // Content
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6C6C70',
    marginBottom: 40,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    color: '#3C3C43',
    marginBottom: 8,
    fontWeight: '600',
  },
  input: {
    borderWidth: 1,
    borderColor: '#C7C7CC',
    borderRadius: 8,
    padding: 15,
    fontSize: 16,
  },
  // Info Box
  infoBox: {
    borderWidth: 1,
    borderColor: '#007AFF',
    backgroundColor: '#F0F8FF',
    borderRadius: 12,
    padding: 15,
    marginTop: 20,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 10,
  },
  infoText: {
    fontSize: 14,
    color: '#333',
    lineHeight: 22,
  },
  // Button
  button: {
    backgroundColor: '#007AFF',
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
  buttonDisabled: {
    backgroundColor: '#A9A9A9',
  },
  // Footer
  footerText: {
    textAlign: 'center',
    marginTop: 20,
    color: '#8A8A8E',
  },
  // Result Screen
  resultContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  resultIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  resultTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  resultSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    paddingHorizontal: 40,
    marginBottom: 20,
  },
  errorCode: {
    fontSize: 14,
    color: '#007AFF',
    textAlign: 'center',
  }
});

export default VehicleRegistrationScreen;
