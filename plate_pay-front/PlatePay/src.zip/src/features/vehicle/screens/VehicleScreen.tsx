import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
  ActivityIndicator,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { Car } from '../../../types/type';
import { getMyCars, deleteCar } from '../../../shared/api/carApi';

const VehicleScreen = ({ navigation }) => {
  const [vehicles, setVehicles] = useState<Car[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [isModalVisible, setModalVisible] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Car | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchVehicles = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await getMyCars();
      setVehicles(data);
    } catch (err) {
      setError('차량 목록을 불러오는 데 실패했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  // useFocusEffect를 사용하여 화면이 포커될 때마다 데이터를 다시 불러옵니다.
  // (차량 등록 후 돌아왔을 때 목록이 갱신되도록)
  useFocusEffect(
    React.useCallback(() => {
      fetchVehicles();
    }, [])
  );

  const handleDeletePress = (vehicle: Car) => {
    setSelectedVehicle(vehicle);
    setModalVisible(true);
  };

  const handleConfirmDelete = async () => {
    if (selectedVehicle) {
      setIsDeleting(true);
      try {
        await deleteCar(selectedVehicle.carUid);
        // 삭제 성공 후 목록을 다시 불러와 화면을 갱신합니다.
        await fetchVehicles();
        Alert.alert('성공', '차량이 삭제되었습니다.');
      } catch (err) {
        Alert.alert('오류', '차량 삭제에 실패했습니다.');
      } finally {
        setIsDeleting(false);
        setModalVisible(false);
        setSelectedVehicle(null);
      }
    }
  };
  
  const registrationContent = (
    <>
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => navigation.navigate('VehicleRegistration')}
      >
        <Text style={styles.addButtonText}>+ 새 차량 등록</Text>
      </TouchableOpacity>
      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>차량 등록 안내</Text>
        <Text style={styles.infoText}> • 한 명의 사용자가 여러 차량을 등록할 수 있습니다</Text>
        <Text style={styles.infoText}> • 동일한 차량 번호는 한 명만 등록 가능합니다</Text>
      </View>
    </>
  );

  const renderContent = () => {
    if (isLoading) {
      return <ActivityIndicator size="large" style={styles.centered} />;
    }
    if (error) {
      return <Text style={styles.centered}>{error}</Text>;
    }
    if (vehicles.length === 0) {
      return <View style={styles.emptyContainer}>{registrationContent}</View>;
    }
    return (
      <ScrollView contentContainerStyle={styles.listContainer}>
        {vehicles.map(vehicle => (
          <View key={vehicle.carUid} style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.carNickname}>{vehicle.nickName}</Text>
            </View>
            <View style={styles.cardBody}>
              <Text style={styles.plateNumber}>{vehicle.plateNum}</Text>
              <Text style={styles.modelText}>{vehicle.carModel}</Text>
            </View>
            <View style={styles.cardFooter}>
               <TouchableOpacity style={styles.mainCarButton}>
                <Text style={styles.mainCarButtonText}>대표차량</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDeletePress(vehicle)}>
                <Icon name="trash" size={24} color="#555" />
              </TouchableOpacity>
            </View>
          </View>
        ))}
        {registrationContent}
      </ScrollView>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {renderContent()}
      <Modal
        animationType="fade"
        transparent={true}
        visible={isModalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>삭제하시겠습니까?</Text>
            <Text style={styles.modalSubtitle}>이 작업은 되돌릴 수 없습니다</Text>
            <View style={styles.modalButtonContainer}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>취소</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.deleteButton, isDeleting && styles.buttonDisabled]}
                onPress={handleConfirmDelete}
                disabled={isDeleting}
              >
                {isDeleting ? <ActivityIndicator color="#FFF" /> : <Text style={styles.deleteButtonText}>삭제</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F7F7F7' },
  listContainer: { padding: 20, paddingBottom: 100 },
  emptyContainer: { flex: 1, justifyContent: 'center', padding: 20 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E5EA',
    marginBottom: 20,
    overflow: 'hidden',
  },
  cardHeader: {
    padding: 15,
    backgroundColor: '#F0F8FF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5EA',
  },
  carNickname: { fontSize: 18, fontWeight: 'bold', color: '#007AFF' },
  cardBody: { padding: 20, alignItems: 'center' },
  plateNumber: { fontSize: 32, fontWeight: 'bold', color: '#000', marginBottom: 10 },
  modelText: { fontSize: 18, color: '#555' },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderTopWidth: 1,
    borderTopColor: '#E5E5EA',
  },
  mainCarButton: {
    borderWidth: 1,
    borderColor: '#007AFF',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  mainCarButtonText: { color: '#007AFF', fontWeight: 'bold' },
  addButton: {
    backgroundColor: '#007AFF',
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: { color: '#FFFFFF', fontSize: 18, fontWeight: '600' },
  infoBox: {
    borderWidth: 1,
    borderColor: '#007AFF',
    backgroundColor: '#F0F8FF',
    borderRadius: 12,
    padding: 15,
  },
  infoTitle: { fontSize: 16, fontWeight: 'bold', color: '#000', marginBottom: 10 },
  infoText: { fontSize: 14, color: '#333', lineHeight: 22 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: '#FFFFFF', borderRadius: 14, padding: 20, width: '85%', alignItems: 'center' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
  modalSubtitle: { fontSize: 16, color: '#666', marginBottom: 25, textAlign: 'center' },
  modalButtonContainer: { flexDirection: 'row', width: '100%' },
  modalButton: { flex: 1, paddingVertical: 12, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#FFF', borderWidth: 1, borderColor: '#CCC', marginRight: 10 },
  cancelButtonText: { color: '#333', fontSize: 16, fontWeight: '600' },
  deleteButton: { backgroundColor: '#FF3B30' },
  deleteButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  buttonDisabled: { backgroundColor: '#A9A9A9' },
});

export default VehicleScreen;