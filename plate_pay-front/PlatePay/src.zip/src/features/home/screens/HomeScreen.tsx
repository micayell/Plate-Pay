import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { getPendingOrderHistory } from '../../../shared/api/orderApi';
import { getMyCars } from '../../../shared/api/carApi';
import { getAccounts } from '../../../shared/api/accountApi';
import { PendingOrderHistory, Car, Account } from '../../../types/type';

export default function HomeScreen() {
  const [pendingOrder, setPendingOrder] = useState<PendingOrderHistory | null>(
    null,
  );
  const [cars, setCars] = useState<Car[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const carsData = await getMyCars();
      setCars(carsData);

      const accountsData = await getAccounts();
      setAccounts(accountsData);

      const firstCar = carsData[0];
      if (firstCar) {
        try {
          const pendingOrderData = await getPendingOrderHistory(
            firstCar.plateNum,
          );
          setPendingOrder(pendingOrderData);
        } catch (e) {
          console.error('Failed to fetch pending order history:', e);
          setPendingOrder(null); // 주문 내역 로딩 실패 시 null 처리
        }
      } else {
        setPendingOrder(null);
      }
    } catch (e) {
      console.error('Failed to fetch car or account data:', e);
      setError('데이터를 불러오는 데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      fetchData();
    }, []),
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR').format(amount) + '원';
  };

  const renderContent = () => {
    if (loading) {
      return (
        <ActivityIndicator size="large" color="#007AFF" style={{ marginTop: 40 }} />
      );
    }

    if (error) {
      return <Text style={styles.errorText}>{error}</Text>;
    }

    const mainCar = cars[0];
    const mainAccount = accounts.find(acc => acc.main) || accounts[0];

    return (
      <>
        {/* Orders Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>주문 중</Text>
          {!mainCar ? (
            <View style={styles.card}>
              <Text>차량을 먼저 등록해주세요.</Text>
            </View>
          ) : pendingOrder &&
            pendingOrder.orders &&
            pendingOrder.orders.length > 0 ? (
            pendingOrder.orders.map(order => (
              <View key={order.orderHistoryId} style={styles.card}>
                <View>
                  <Text style={styles.orderStore}>{order.storeName}</Text>
                  <Text style={styles.orderTime}>
                    {pendingOrder.parkingLotName}
                  </Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={styles.orderPrice}>
                    {formatCurrency(order.cost)}
                  </Text>
                  <Text style={styles.orderType}>상품구매</Text>
                </View>
              </View>
            ))
          ) : (
            <View style={styles.card}>
              <Text>주문 내역이 없습니다.</Text>
            </View>
          )}
        </View>

        {/* Account Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>결제 계좌</Text>
          {mainAccount ? (
            <View style={[styles.card, styles.rowBetween]}>
              <View style={styles.row}>
                <View style={styles.bankIcon} />
                <View>
                  <Text style={styles.bankName}>{mainAccount.bankName}</Text>
                  <Text style={styles.accountNumber}>
                    {mainAccount.accountNo}
                  </Text>
                </View>
              </View>
              <Icon name="chevron-forward" size={20} color="#8E8E93" />
            </View>
          ) : (
            <View style={styles.card}>
              <Text>등록된 결제 계좌가 없습니다.</Text>
            </View>
          )}
        </View>

        {/* Vehicle Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>결제 차량</Text>
          {mainCar ? (
            <View style={[styles.card, styles.rowBetween]}>
              <Text style={styles.carNumber}>{mainCar.plateNum}</Text>
              <Text style={styles.carName}>{mainCar.carModel}</Text>
            </View>
          ) : (
            <View style={styles.card}>
              <Text>등록된 차량이 없습니다.</Text>
            </View>
          )}
        </View>
      </>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={{ width: 30 }} />
        <Text style={styles.headerTitle}>홈</Text>
        <Icon name="person-circle-outline" size={30} color="#333" />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {renderContent()}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9F9F9' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
  },
  headerTitle: { flex: 1, textAlign: 'center', fontSize: 22, fontWeight: 'bold' },
  scrollContent: { padding: 16 },
  section: { marginTop: 24 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
    elevation: 1,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 3,
  },
  orderStore: { fontSize: 16, fontWeight: 'bold', color: '#111' },
  orderTime: { fontSize: 12, color: '#8E8E93', marginTop: 4 },
  orderPrice: { fontSize: 16, fontWeight: 'bold' },
  orderType: { fontSize: 12, color: '#8E8E93', marginTop: 4 },
  row: { flexDirection: 'row', alignItems: 'center' },
  rowBetween: { justifyContent: 'space-between' },
  bankIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#E0E0E0',
    marginRight: 12,
  },
  bankName: { fontSize: 16, fontWeight: '500' },
  accountNumber: { fontSize: 12, color: '#8E8E93', marginTop: 2 },
  carNumber: { fontSize: 16, fontWeight: '500' },
  carName: { fontSize: 16, color: '#555' },
  errorText: {
    textAlign: 'center',
    marginTop: 20,
    color: 'red',
    fontSize: 16,
  },
});
