import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SectionList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Ionicons';
import { Calendar, LocaleConfig } from 'react-native-calendars';
import { useNavigation } from '@react-navigation/native';
import TransactionItem from '../components/TransactionItem';

// react-native-calendars 한글 설정
LocaleConfig.locales['kr'] = {
  monthNames: [
    '1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월',
  ],
  monthNamesShort: [
    '1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.', '10.', '11.', '12.',
  ],
  dayNames: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
  dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
  today: '오늘',
};
LocaleConfig.defaultLocale = 'kr';

// MOCK DATA
const MOCK_DATA = {
  '2025-09-01': [
    { id: 'm1', store: '이마트 주차장', amount: 60000, type: '주차' },
  ],
  '2025-09-07': [
    { id: 'm2', store: '스타벅스', amount: 7500, type: '쇼핑' },
    { id: 'm3', store: '메가박스', amount: 25000, type: '쇼핑' },
  ],
};

export default function MonthlyTransactionScreen() {
  const navigation = useNavigation();
  const [selectedDate, setSelectedDate] = useState('2025-09-01');
  const [currentMonth, setCurrentMonth] = useState(new Date('2025-09-01'));

  const markedDates = useMemo(() => {
    const marks = {};
    Object.keys(MOCK_DATA).forEach(date => {
      marks[date] = {
        marked: true,
        dotColor: '#0064FF',
      };
    });
    if (selectedDate) {
      marks[selectedDate] = {
        ...marks[selectedDate],
        selected: true,
        selectedColor: '#0064FF',
      };
    }
    return marks;
  }, [selectedDate]);
  
  const transactionsForSelectedDate = MOCK_DATA[selectedDate] || [];
  const sections =
    transactionsForSelectedDate.length > 0
      ? [{ title: selectedDate, data: transactionsForSelectedDate }]
      : [];
      
  const handleMonthChange = (isNext) => {
    const newMonth = new Date(currentMonth);
    newMonth.setMonth(newMonth.getMonth() + (isNext ? 1 : -1));
    setCurrentMonth(newMonth);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>월별 거래 내역</Text>
        <TouchableOpacity>
          <Icon name="person-circle-outline" size={30} color="#333" />
        </TouchableOpacity>
      </View>

      <View style={styles.calendarHeader}>
        <TouchableOpacity onPress={() => handleMonthChange(false)}>
          <Icon name="chevron-back" size={22} color="#000" />
        </TouchableOpacity>
        <Text style={styles.calendarMonthText}>
            {`${currentMonth.getMonth() + 1}월`}
        </Text>
        <TouchableOpacity onPress={() => handleMonthChange(true)}>
          <Icon name="chevron-forward" size={22} color="#CECECE" />
        </TouchableOpacity>
      </View>
      
      <Calendar
        key={currentMonth.toISOString()} // 월이 변경될 때 캘린더를 리렌더링하기 위함
        current={currentMonth.toISOString().split('T')[0]}
        onDayPress={day => setSelectedDate(day.dateString)}
        markedDates={markedDates}
        monthFormat={' '} // 기본 월 형식은 숨김
        onMonthChange={month => {
            const newDate = new Date(month.dateString);
            setCurrentMonth(newDate);
        }}
        hideExtraDays={true}
        theme={{
            arrowColor: '#000',
            todayTextColor: '#0064FF',
            textSectionTitleColor: '#7E818C',
            selectedDayBackgroundColor: '#0064FF',
            selectedDayTextColor: '#ffffff',
            dayTextColor: '#0F2552',
        }}
      />
      
      <View style={styles.divider} />

      <SectionList
        sections={sections}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <TransactionItem {...item} />}
        renderSectionHeader={({ section: { title } }) => (
          <Text style={styles.sectionHeader}>{formatDate(title)}</Text>
        )}
        ListEmptyComponent={
            <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>선택한 날짜에 거래 내역이 없습니다.</Text>
            </View>
        }
      />
    </SafeAreaView>
  );
}

const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate();
    const weekday = LocaleConfig.locales['kr'].dayNames[date.getDay()];
    return `${day}일 ${weekday}`;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerTitle: { fontSize: 18, fontWeight: '600', color: '#000000' },
  calendarHeader: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
  },
  calendarMonthText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
    marginHorizontal: 15,
  },
  divider: {
    height: 8,
    backgroundColor: '#F5F5F5',
    marginVertical: 10,
  },
  sectionHeader: {
    paddingHorizontal: 21,
    paddingTop: 10,
    paddingBottom: 8,
    fontSize: 15,
    fontWeight: '600',
    color: '#C5C5C5',
    backgroundColor: '#FFFFFF',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    marginTop: 50,
  },
  emptyText: {
    fontSize: 16,
    color: '#888',
  },
});
