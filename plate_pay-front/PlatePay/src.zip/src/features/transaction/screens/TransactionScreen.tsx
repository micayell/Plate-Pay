import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SectionList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import TransactionItem from '../components/TransactionItem';
import TransactionDetailModal from '../components/TransactionDetailModal';

// MOCK DATA - API 연결 전 임시 데이터입니다.
const MOCK_TRANSACTIONS = [
  {
    title: '7일 일요일',
    data: [
      {
        id: 't1',
        store: '이마트 주차장',
        amount: 15000,
        type: '주차',
        address: '광주광역시 광산구 상무대로 420-25',
        datetime: '2025-09-07 12:34:56',
        accountName: '이유희의 계좌',
        carNumber: '123가 4567',
        breakdown: [
          { item: '채씨네 과일', type: '쇼핑', amount: 5000 },
          { item: '올리브영', type: '쇼핑', amount: 10000 },
          { item: '주차비', type: '주차', amount: 5000 },
        ],
      },
      { id: 't2', store: '이바돔 주차장', amount: 15000, type: '주차' },
      { id: 't3', store: '스타벅스 주차장', amount: 15000, type: '주차' },
      { id: 't4', store: '이마트 주차장', amount: 15000, type: '주차' },
    ],
  },
  {
    title: '6일 토요일',
    data: [
      { id: 't5', store: '삼성 광주 주차장', amount: 15000, type: '주차' },
      { id: 't6', store: '이마트', amount: 15000, type: '쇼핑' },
      { id: 't7', store: '이마트', amount: 15000, type: '쇼핑' },
      { id: 't8', store: '이마트', amount: 15000, type: '쇼핑' },
    ],
  },
];

export default function TransactionScreen() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  const handleItemPress = (item) => {
    // 상세 정보가 있는 경우에만 모달을 띄우도록 (임시)
    if (item.address) {
      setSelectedTransaction(item);
      setModalVisible(true);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={{ width: 30 }} />
        <Text style={styles.headerTitle}>최근 거래 내역</Text>
        <TouchableOpacity>
          <Icon name="person-circle-outline" size={30} color="#333" />
        </TouchableOpacity>
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('MonthlyTransaction')}
        >
          <Text style={styles.buttonText}>월별 내역</Text>
        </TouchableOpacity>
      </View>

      <SectionList
        sections={MOCK_TRANSACTIONS}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TransactionItem
            store={item.store}
            amount={item.amount}
            type={item.type}
            onPress={() => handleItemPress(item)}
          />
        )}
        renderSectionHeader={({ section: { title } }) => (
          <Text style={styles.sectionHeader}>{title}</Text>
        )}
        showsVerticalScrollIndicator={false}
      />
      
      {selectedTransaction && (
        <TransactionDetailModal
          visible={modalVisible}
          onClose={() => setModalVisible(false)}
          transaction={selectedTransaction}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000000',
  },
  buttonContainer: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  button: {
    backgroundColor: '#0064FF',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  sectionHeader: {
    paddingHorizontal: 21,
    paddingTop: 16,
    paddingBottom: 8,
    fontSize: 15,
    fontWeight: '600',
    color: '#C5C5C5',
    backgroundColor: '#FFFFFF',
  },
});
