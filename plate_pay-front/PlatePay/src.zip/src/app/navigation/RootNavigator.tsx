import React from 'react';
// NavigationContainer와 함께 DefaultTheme를 import 합니다.
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import {
  createNativeStackNavigator,
  NativeStackScreenProps,
} from '@react-navigation/native-stack';

import LoginScreen from '../../features/auth/screens/LoginScreen';
import SignupScreen from '../../features/auth/screens/SignupScreen';
import PinSetupScreen from '../../features/auth/screens/PinSetupScreen';
import KakaoLoginScreen from '../../features/auth/screens/KakaoLoginScreen';
import SsafyLoginScreen from '../../features/auth/screens/SsafyLoginScreen';
import BottomTabNavigator from './BottomTabNavigator';
import { MemberInfo } from '../../shared/state/authStore';
import AddAccountScreen from '../../features/wallet/screens/AddAccountScreen';
import VerifyAccountScreen from '../../features/wallet/screens/VerifyAccountScreen';

// 네비게이터가 관리할 화면들의 목록과 필요한 파라미터 타입을 정의합니다.
export type RootStackParamList = {
  Login: undefined; // Login 화면은 파라미터가 필요 없습니다.
  // Signup 스크린으로 이동할 때 memberInfo 객체를 전달하도록 타입을 수정합니다.
  Signup: { memberInfo: MemberInfo };
  PinSetup: {
    name: string | null;
    nickname: string | null;
    phoneNum: string;
  };
  KakaoLogin: undefined; // KakaoLogin 화면 추가
  SsafyLogin: undefined; // SsafyLogin 화면 추가
  MainApp: undefined; // 메인 앱(하단 탭) 화면 추가
};

const Stack = createNativeStackNavigator<RootStackParamList>();

// 앱 전체의 배경색을 흰색으로 설정하는 테마를 정의합니다.
const theme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: 'white' },
};

// App 전체의 화면 흐름을 정의하는 네비게이터 컴포넌트입니다.
export default function RootNavigator() {
  return (
    // NavigationContainer에 theme prop을 전달합니다.
    <NavigationContainer theme={theme}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Signup" component={SignupScreen} />
        <Stack.Screen name="PinSetup" component={PinSetupScreen} />
        <Stack.Screen name="KakaoLogin" component={KakaoLoginScreen} />
        <Stack.Screen name="SsafyLogin" component={SsafyLoginScreen} />
        <Stack.Screen name="MainApp" component={BottomTabNavigator} />
        <Stack.Screen name="AddAccount" component={AddAccountScreen} />
        <Stack.Screen
          name="VerifyAccount"
          component={VerifyAccountScreen}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// 다른 화면에서 navigation, route prop의 타입을 쉽게 사용하기 위해 export 합니다.
export type ScreenProps<T extends keyof RootStackParamList> =
  NativeStackScreenProps<RootStackParamList, T>;
