export interface Order {
  orderHistoryId: number;
  storeName: string;
  cost: number;
  isPaid: boolean;
}

export interface PendingOrderHistory {
  inOutHistoryId: number;
  parkingLotUid: number;
  parkingLotName: string;
  address: string;
  plateNum: string;
  bankName: string;
  accountNo: string;
  outTime: string | null;
  orders: Order[];
  totalCost: number;
}

export interface Car {
  carUid: number;
  nickName: string;
  plateNum: string;
  carModel: string;
}

export interface Account {
  accountId: number;
  bankName: string;
  accountName: string;
  accountNo: string;
  main: boolean;
}

export interface VehicleRegistrationRequest {
  name: string;
  nickname: string;
  carNo: string;
  ssn: string; // 주민번호 앞 6자리 + 뒤 7자리
}

export interface VehicleRegistrationResponse {
  code: string;
  jobIndex?: number;
  threadIndex?: number;
  jti?: string;
  twoWayTimestamp?: number;
}

export interface ApiResponse<T> {
  state: number;
  result: string;
  message: string | null;
  data: T;
  error: any[];
}