
import React, { useEffect } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { enableScreens } from "react-native-screens";
import RootNavigator from './src/app/navigation/RootNavigator';
import PartnershipScreen from "./src/features/partnership/screens/PartnershipScreen";
import { getApps, getApp } from '@react-native-firebase/app';

enableScreens();

export default function App() {
  useEffect(() => {
    const initializeFirebase = () => {
      try {
        console.log('🔥 APP: Starting Firebase initialization...');
        console.log('🔥 APP: Firebase apps count:', getApps().length);

        // Firebase 자동 초기화 확인
        if (getApps().length > 0) {
          console.log('🔥 APP: ✅ Firebase already initialized!');
          console.log('🔥 APP: Default app name:', getApp().name);

          // FCM 서비스 초기화
          const FCMService = require('./src/services/FCMService').default;
          console.log('🔥 APP: FCMService imported successfully');
        } else {
          console.log('🔥 APP: Waiting for Firebase auto-initialization...');

          // Firebase 자동 초기화를 기다림
          let attempts = 0;
          const checkFirebase = setInterval(() => {
            attempts++;
            console.log(`🔥 APP: Checking Firebase apps, attempt ${attempts}`);

            if (getApps().length > 0) {
              console.log('🔥 APP: ✅ Firebase auto-initialized successfully!');
              console.log('🔥 APP: Default app name:', getApp().name);

              clearInterval(checkFirebase);

              // FCM 서비스 초기화
              const FCMService = require('./src/services/FCMService').default;
              console.log('🔥 APP: FCMService imported successfully');
            } else if (attempts >= 30) {
              console.log('🔥 APP: ❌ Firebase auto-initialization timeout');
              clearInterval(checkFirebase);
            }
          }, 100);
        }
      } catch (error) {
        console.log('🔥 APP: ❌ Firebase initialization error:', error.message);
      }
    };

    // 약간의 지연 후 초기화 시도
    setTimeout(initializeFirebase, 1000);
  }, []);

  return (
    <SafeAreaProvider>
      <RootNavigator />
      {/* <PartnershipScreen/> */}

    </SafeAreaProvider>
  );
}
